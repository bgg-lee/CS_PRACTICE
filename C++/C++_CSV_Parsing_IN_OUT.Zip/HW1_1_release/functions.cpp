#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <map>
#include <vector>

#include "functions.hpp"

using namespace std;
void ParseCSV(const std::string & filename, std::map<int, std::string> & header_cols, map<std::string, vector<std::string>> & data_map){

    ifstream file(filename);
    if(!file.is_open()){
        cerr << "ERROR";
        return;
    }

    string line;
    int col = 0 ;

    while(getline(file,line)){
        //header 작업
        stringstream ss(line);
        string str;
        string data;
        string keep;
        string head;
        bool row_cond = true;
        int iter = 0;
        vector<string> row_data={};

        if(col==0){
            while(getline(ss,str,',')){
                header_cols[col] = str;
                col++;
            }
        }

       //data_map 작업
        else{
            while(getline(ss,data,',')){
             
                //empty data in the row
                if(data.empty()){
                    row_cond = false;
                    break;
                }
                // col 길이 초과
                if(iter>=header_cols.size()){
                    row_cond = false;
                    break;
                }
                // double quoto
                if(data.front()=='"' && data.back()!='"'){
                    keep = data;
                    continue;
                }
                if(data.front()!='"' && data.back()=='"'){
                    data = keep + "," + data;
                }

                row_data.push_back(data);
                iter++;
            }

            if(row_cond){
                for(int i = 0 ; i<row_data.size();i++){
                    data_map[header_cols[i]].push_back(row_data[i]);
                }
            }
        }
    }
    file.close();
}
// Sum all elements in the column  
int SumColumn(const std::string &column_name, map<std::string, vector<std::string>> &data_map){

    int sum = 0;
    for(int i = 0; i < data_map[column_name].size();i++){
        sum += stoi(data_map[column_name][i]);
    }

    return sum;
}


double FilterMostFrequentAvg(const std::string &key_col, std::string &value_col, map<std::string, vector<std::string>> &data_map){

    map<string,double> cnt;
    for(auto x : data_map[key_col]){
        if(!cnt[x]){
            cnt[x] = 1;
        }else{
            cnt[x]++;
        }
    }

    double intmax=0;
    string ans;
    for(auto p : cnt){
        if(p.second > intmax){
            intmax = p.second;
            ans = p.first;
        }
    }
    double sum = 0;

    for(int i=0;i<data_map[key_col].size();i++){
        if(data_map[key_col][i]==ans){
            sum = sum + stoi(data_map[value_col][i]);
        }
    }

    return sum/intmax;
}


void SumTwoColumns(std::string &value_col1, std::string &value_col2, const std::string & out_filename, std::map<int, std::string> & header_cols, map<std::string, vector<std::string>> & data_map){

    ofstream file(out_filename);
    for(auto p : header_cols){
        file << p.second <<",";
    }
    file << "SumOf"<<value_col1<<"And"<<value_col2<<endl;
    
    auto it1 = data_map.find(value_col1);
    auto it2 = data_map.find(value_col2);

    for(int i=0; i<it1->second.size();i++){
        for(auto it = header_cols.begin();it!=header_cols.end();it++){
            file << data_map[it->second][i] << ",";
        }
        file << stoi((it1->second)[i])+stoi((it2->second)[i])<< endl;
    }

    file.close();
}